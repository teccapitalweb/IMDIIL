/* ========================================================================
   IMDIIL VIP · service-worker.js
   Offline-first para herramientas pro: un supervisor sin señal en planta
   puede abrir IPER, OEE, ATS desde su celular instalado como PWA.
   ======================================================================== */

const CACHE_VERSION = 'imdiil-v1.0.0';
const STATIC_CACHE = CACHE_VERSION + '-static';
const RUNTIME_CACHE = CACHE_VERSION + '-runtime';

// Archivos críticos a cachear en instalación
const STATIC_ASSETS = [
  '/vip-panel.html',
  '/css/core.css',
  '/css/components.css',
  '/css/tools.css',
  '/css/responsive.css',
  '/js/app.js',
  '/js/modal.js',
  '/js/storage.js',
  '/js/pdf-engine.js',
  '/js/tools/iper.js',
  '/js/tools/oee.js',
  '/js/tools/ats.js',
  '/js/tools/noms.js',
  '/js/tools/logistica.js',
  '/manifest.json'
];

// Instalación: precache de estáticos
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(STATIC_CACHE).then((cache) => {
      return cache.addAll(STATIC_ASSETS).catch((err) => {
        // No fallar si algún archivo no existe aún
        console.warn('[SW] Algunos assets no se pudieron cachear:', err);
      });
    }).then(() => self.skipWaiting())
  );
});

// Activación: limpiar caches viejos
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(
        keys.filter((k) => k.startsWith('imdiil-') && k !== STATIC_CACHE && k !== RUNTIME_CACHE)
            .map((k) => caches.delete(k))
      )
    ).then(() => self.clients.claim())
  );
});

// Fetch: estrategias por tipo de recurso
self.addEventListener('fetch', (event) => {
  const { request } = event;
  if (request.method !== 'GET') return;

  const url = new URL(request.url);

  // No interceptar requests cross-origin (CDN de jsPDF, Google Fonts, Firebase, etc.)
  // Excepción: Google Fonts → cache-first para que el panel se vea bien offline
  if (url.origin !== self.location.origin) {
    if (url.hostname === 'fonts.googleapis.com' || url.hostname === 'fonts.gstatic.com') {
      event.respondWith(cacheFirst(request));
    }
    return;
  }

  // HTML: network-first (siempre intenta lo más nuevo, fallback a cache)
  if (request.mode === 'navigate' || (request.headers.get('accept') || '').includes('text/html')) {
    event.respondWith(networkFirst(request));
    return;
  }

  // CSS, JS, imágenes: cache-first
  if (/\.(css|js|png|jpg|jpeg|webp|svg|ico|woff2?|json)$/i.test(url.pathname)) {
    event.respondWith(cacheFirst(request));
    return;
  }

  // Default: network con fallback a cache
  event.respondWith(networkFirst(request));
});

async function cacheFirst(request) {
  const cached = await caches.match(request);
  if (cached) return cached;
  try {
    const response = await fetch(request);
    if (response && response.status === 200 && response.type === 'basic') {
      const cache = await caches.open(RUNTIME_CACHE);
      cache.put(request, response.clone());
    }
    return response;
  } catch (err) {
    // Si todo falla y es una navegación, devolver la página principal cacheada
    const fallback = await caches.match('/vip-panel.html');
    if (fallback) return fallback;
    throw err;
  }
}

async function networkFirst(request) {
  try {
    const response = await fetch(request);
    if (response && response.status === 200 && response.type === 'basic') {
      const cache = await caches.open(RUNTIME_CACHE);
      cache.put(request, response.clone());
    }
    return response;
  } catch (err) {
    const cached = await caches.match(request);
    if (cached) return cached;
    // Fallback final: si pide HTML y no hay nada, devolver vip-panel cacheado
    if ((request.headers.get('accept') || '').includes('text/html')) {
      const offline = await caches.match('/vip-panel.html');
      if (offline) return offline;
    }
    throw err;
  }
}
