/* ========================================================================
   IMDIIL VIP · app.js
   Orquestador principal del panel.
   - Init de tema (día/noche)
   - Saludo dinámico por hora
   - Contadores KPI animados
   - Countdown del próximo webinar
   - Navigation handler (resaltar sección activa)
   - Sistema de toasts
   - Wire-up de las herramientas pro
   ======================================================================== */

(function (global) {
  'use strict';

  const App = {
    isReady: false,
    onReadyCallbacks: []
  };

  /* ========================================================================
     THEME (día / noche)
     ======================================================================== */
  const Theme = {
    init() {
      const saved = IMDIILStorage.pref.get('theme', 'night');
      this.apply(saved);
      const btn = document.getElementById('theme-toggle');
      if (btn) btn.addEventListener('click', () => this.toggle());
    },

    apply(t) {
      if (t !== 'day' && t !== 'night') t = 'night';
      document.documentElement.setAttribute('data-theme', t);
      IMDIILStorage.pref.set('theme', t);
      this.updateToggleUI(t);
      this.updateMetaThemeColor(t);
    },

    toggle() {
      const current = document.documentElement.getAttribute('data-theme');
      this.apply(current === 'night' ? 'day' : 'night');
    },

    updateToggleUI(t) {
      const icon = document.getElementById('theme-icon');
      const label = document.getElementById('theme-label');
      if (icon) {
        const use = icon.querySelector('use');
        if (use) use.setAttribute('href', t === 'night' ? '#i-moon' : '#i-sun');
      }
      if (label) label.textContent = t === 'night' ? 'Noche' : 'Día';
    },

    updateMetaThemeColor(t) {
      const meta = document.querySelector('meta[name="theme-color"]:not([media])');
      if (meta) meta.setAttribute('content', t === 'night' ? '#0E0A06' : '#F4EFE3');
    }
  };

  /* ========================================================================
     GREETING (saludo según hora)
     ======================================================================== */
  function applyGreeting() {
    const h = new Date().getHours();
    const greet = h < 12 ? 'Buen día' : h < 19 ? 'Buenas tardes' : 'Buenas noches';
    const eyebrow = h < 12 ? 'Hoy es un buen día'
                  : h < 19 ? 'Tarde productiva'
                  : 'Cerrando con todo';

    const title = document.getElementById('hero-title');
    const labelEl = document.getElementById('greeting-label');
    if (title) title.innerHTML = greet + ', <em>ingeniero</em>';
    if (labelEl) labelEl.textContent = eyebrow;
  }

  /* ========================================================================
     KPI COUNTERS (animación de números)
     ======================================================================== */
  function animateCounters() {
    document.querySelectorAll('.kpi__value[data-count]').forEach(el => {
      const target = parseInt(el.dataset.count, 10);
      if (isNaN(target)) return;
      const duration = 1100;
      const start = performance.now();
      function tick(now) {
        const p = Math.min((now - start) / duration, 1);
        const eased = 1 - Math.pow(1 - p, 3);
        el.textContent = Math.round(target * eased);
        if (p < 1) requestAnimationFrame(tick);
      }
      setTimeout(() => requestAnimationFrame(tick), 200);
    });
  }

  /* ========================================================================
     COUNTDOWN (próximo webinar)
     ======================================================================== */
  function initCountdown() {
    const el = document.getElementById('countdown');
    if (!el) return;
    const targetIso = el.dataset.target;
    let target;
    if (targetIso) {
      target = new Date(targetIso);
    } else {
      target = new Date();
      target.setDate(target.getDate() + 5);
      target.setHours(19, 0, 0, 0);
    }

    const cd = {
      d: document.getElementById('cd-d'),
      h: document.getElementById('cd-h'),
      m: document.getElementById('cd-m'),
      s: document.getElementById('cd-s')
    };
    const pad = n => String(n).padStart(2, '0');

    function tick() {
      const diff = target - new Date();
      if (diff <= 0) {
        if (cd.d) cd.d.textContent = '00';
        if (cd.h) cd.h.textContent = '00';
        if (cd.m) cd.m.textContent = '00';
        if (cd.s) cd.s.textContent = '00';
        return;
      }
      const d = Math.floor(diff / 86400000);
      const h = Math.floor((diff % 86400000) / 3600000);
      const m = Math.floor((diff % 3600000) / 60000);
      const s = Math.floor((diff % 60000) / 1000);
      if (cd.d) cd.d.textContent = pad(d);
      if (cd.h) cd.h.textContent = pad(h);
      if (cd.m) cd.m.textContent = pad(m);
      if (cd.s) cd.s.textContent = pad(s);
    }
    tick();
    setInterval(tick, 1000);
  }

  /* ========================================================================
     NAVIGATION (sidebar + mobile bottom nav)
     ======================================================================== */
  function initNavigation() {
    document.querySelectorAll('.nav-item[data-section]').forEach(item => {
      item.addEventListener('click', (e) => {
        e.preventDefault();
        const section = item.dataset.section;

        // Resaltar visualmente
        document.querySelectorAll('.nav-item').forEach(i => i.classList.remove('is-active'));
        item.classList.add('is-active');

        // Disparar evento global para que las herramientas escuchen
        document.dispatchEvent(new CustomEvent('imdiil:navigate', { detail: { section } }));

        // Si es una herramienta pro, abrirla
        const toolHandlers = {
          iper: () => global.IMDIILTools?.iper?.open(),
          oee: () => global.IMDIILTools?.oee?.open(),
          ats: () => global.IMDIILTools?.ats?.open(),
          noms: () => global.IMDIILTools?.noms?.open(),
          logistica: () => global.IMDIILTools?.logistica?.open()
        };
        if (toolHandlers[section]) {
          toolHandlers[section]();
        }
      });
    });

    // Cards de herramientas (botones grandes en el body)
    document.querySelectorAll('.tool[data-tool]').forEach(tool => {
      tool.addEventListener('click', () => {
        const which = tool.dataset.tool;
        const handler = global.IMDIILTools?.[which]?.open;
        if (handler) handler();
        else toast.info('Herramienta en construcción', 'Pronto disponible.');
      });
    });
  }

  /* ========================================================================
     TOAST SYSTEM
     ======================================================================== */
  const toast = (function () {
    let container = null;

    function ensureContainer() {
      if (!container) {
        container = document.createElement('div');
        container.className = 'toast-container';
        document.body.appendChild(container);
      }
      return container;
    }

    function show(type, title, msg, duration = 3500) {
      const c = ensureContainer();
      const el = document.createElement('div');
      el.className = 'toast toast--' + type;
      const iconMap = { success: 'i-check-circle', error: 'i-alert-circle', info: 'i-info' };
      el.innerHTML =
        '<div class="toast__icon"><svg class="ic"><use href="#' + (iconMap[type] || 'i-info') + '"/></svg></div>' +
        '<div class="toast__body">' +
        '<div class="toast__title">' + (title || '') + '</div>' +
        (msg ? '<div class="toast__msg">' + msg + '</div>' : '') +
        '</div>';
      c.appendChild(el);
      requestAnimationFrame(() => el.classList.add('is-show'));
      setTimeout(() => {
        el.classList.remove('is-show');
        setTimeout(() => el.remove(), 400);
      }, duration);
    }

    return {
      success: (t, m, d) => show('success', t, m, d),
      error:   (t, m, d) => show('error', t, m, d),
      info:    (t, m, d) => show('info', t, m, d)
    };
  })();

  /* ========================================================================
     PUBLIC API
     ======================================================================== */
  App.toast = toast;
  App.theme = Theme;

  App.ready = function (cb) {
    if (this.isReady) cb();
    else this.onReadyCallbacks.push(cb);
  };

  /* ========================================================================
     INIT
     ======================================================================== */
  function init() {
    Theme.init();
    applyGreeting();
    animateCounters();
    initCountdown();
    initNavigation();

    App.isReady = true;
    App.onReadyCallbacks.forEach(cb => cb());

    document.dispatchEvent(new CustomEvent('imdiil:ready'));
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

  global.IMDIILApp = App;
})(window);
