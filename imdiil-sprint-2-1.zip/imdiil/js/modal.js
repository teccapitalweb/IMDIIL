/* ========================================================================
   IMDIIL VIP · modal.js
   Sistema de modales reutilizable.
   - Focus trap accesible (Tab/Shift+Tab quedan dentro)
   - ESC cierra
   - Click en backdrop cierra
   - Lock scroll del body
   - Animación de entrada/salida
   - Stack de modales (puede haber varios abiertos)

   ⚠️  SEGURIDAD: cuando pases `body` como string HTML, este se asigna con
   innerHTML, por lo que NO debes pasar contenido proveniente de input del
   usuario sin escapar primero. Para datos del usuario, pasa un Node creado
   con document.createElement() + textContent en lugar de un string.
   ======================================================================== */

(function (global) {
  'use strict';

  const stack = [];
  let bodyScrollLock = null;

  function lockBody() {
    if (bodyScrollLock !== null) return;
    bodyScrollLock = {
      paddingRight: document.body.style.paddingRight,
      overflow: document.body.style.overflow
    };
    // Compensar scrollbar para que no salte la página
    const sw = window.innerWidth - document.documentElement.clientWidth;
    if (sw > 0) document.body.style.paddingRight = sw + 'px';
    document.body.style.overflow = 'hidden';
  }

  function unlockBody() {
    if (bodyScrollLock === null) return;
    document.body.style.paddingRight = bodyScrollLock.paddingRight;
    document.body.style.overflow = bodyScrollLock.overflow;
    bodyScrollLock = null;
  }

  function getFocusable(root) {
    return Array.from(root.querySelectorAll(
      'a[href], button:not([disabled]), input:not([disabled]):not([type="hidden"]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])'
    )).filter(el => el.offsetParent !== null);
  }

  function trapFocus(e, modal) {
    if (e.key !== 'Tab') return;
    const focusable = getFocusable(modal);
    if (focusable.length === 0) return;
    const first = focusable[0];
    const last = focusable[focusable.length - 1];
    if (e.shiftKey && document.activeElement === first) {
      e.preventDefault(); last.focus();
    } else if (!e.shiftKey && document.activeElement === last) {
      e.preventDefault(); first.focus();
    }
  }

  function onKeydown(e) {
    if (stack.length === 0) return;
    const top = stack[stack.length - 1];
    if (e.key === 'Escape' && top.options.closeOnEsc !== false) {
      e.preventDefault();
      close(top.id);
    } else if (e.key === 'Tab') {
      trapFocus(e, top.element.querySelector('.modal'));
    }
  }

  document.addEventListener('keydown', onKeydown);

  /* ========================================================================
     buildModal — crea el DOM del modal desde una config
     ======================================================================== */
  function buildModal(config) {
    const {
      id, title, subtitle, icon, size, body, footer,
      closeOnBackdrop = true
    } = config;

    const backdrop = document.createElement('div');
    backdrop.className = 'modal-backdrop';
    backdrop.setAttribute('role', 'dialog');
    backdrop.setAttribute('aria-modal', 'true');
    backdrop.setAttribute('aria-labelledby', id + '-title');
    backdrop.dataset.modalId = id;

    const modal = document.createElement('div');
    modal.className = 'modal' + (size === 'lg' ? ' modal--lg' : size === 'sm' ? ' modal--sm' : '');

    // Header
    if (title) {
      const header = document.createElement('div');
      header.className = 'modal__header';

      const titleWrap = document.createElement('div');
      titleWrap.className = 'modal__title-wrap';

      if (icon) {
        const iconEl = document.createElement('div');
        iconEl.className = 'modal__icon';
        iconEl.innerHTML = '<svg class="ic"><use href="#' + icon + '"/></svg>';
        titleWrap.appendChild(iconEl);
      }

      const titles = document.createElement('div');
      const titleEl = document.createElement('div');
      titleEl.className = 'modal__title';
      titleEl.id = id + '-title';
      titleEl.textContent = title;
      titles.appendChild(titleEl);

      if (subtitle) {
        const subEl = document.createElement('div');
        subEl.className = 'modal__subtitle';
        subEl.textContent = subtitle;
        titles.appendChild(subEl);
      }
      titleWrap.appendChild(titles);
      header.appendChild(titleWrap);

      const closeBtn = document.createElement('button');
      closeBtn.className = 'modal__close';
      closeBtn.setAttribute('aria-label', 'Cerrar');
      closeBtn.innerHTML = '<svg class="ic"><use href="#i-close"/></svg>';
      closeBtn.addEventListener('click', () => close(id));
      header.appendChild(closeBtn);

      modal.appendChild(header);
    }

    // Body
    const bodyEl = document.createElement('div');
    bodyEl.className = 'modal__body';
    if (typeof body === 'string') bodyEl.innerHTML = body;
    else if (body instanceof Node) bodyEl.appendChild(body);
    modal.appendChild(bodyEl);

    // Footer
    if (footer) {
      const footerEl = document.createElement('div');
      footerEl.className = 'modal__footer';
      if (typeof footer === 'string') footerEl.innerHTML = footer;
      else if (footer instanceof Node) footerEl.appendChild(footer);
      modal.appendChild(footerEl);
    }

    backdrop.appendChild(modal);

    if (closeOnBackdrop) {
      backdrop.addEventListener('click', (e) => {
        if (e.target === backdrop) close(id);
      });
    }

    return backdrop;
  }

  /* ========================================================================
     open(config) — abre un modal
     ======================================================================== */
  function open(config) {
    if (!config.id) config.id = 'modal_' + Date.now().toString(36);

    // Si ya existe uno con ese id, ciérralo primero
    const existing = stack.find(s => s.id === config.id);
    if (existing) close(config.id);

    const element = buildModal(config);
    document.body.appendChild(element);

    const entry = {
      id: config.id,
      element,
      options: config,
      previousFocus: document.activeElement,
      onClose: config.onClose
    };
    stack.push(entry);
    lockBody();

    // Doble RAF para que la animación corra correctamente
    requestAnimationFrame(() => {
      requestAnimationFrame(() => {
        element.classList.add('is-open');
        // Focus inteligente: prioriza elementos del body (mejor UX en formularios).
        // Si no hay focusables en el body, cae al primer focusable del modal completo.
        const bodyEl = element.querySelector('.modal__body');
        let focusables = bodyEl ? getFocusable(bodyEl) : [];
        if (focusables.length === 0) {
          focusables = getFocusable(element.querySelector('.modal'));
        }
        if (focusables.length) focusables[0].focus();
      });
    });

    return {
      id: config.id,
      element,
      bodyEl: element.querySelector('.modal__body'),
      footerEl: element.querySelector('.modal__footer'),
      close: () => close(config.id),
      query: (sel) => element.querySelector(sel),
      queryAll: (sel) => element.querySelectorAll(sel)
    };
  }

  /* ========================================================================
     close(id) — cierra un modal por id
     ======================================================================== */
  function close(id) {
    const idx = stack.findIndex(s => s.id === id);
    if (idx === -1) return;
    const entry = stack[idx];
    entry.element.classList.remove('is-open');

    setTimeout(() => {
      if (entry.element.parentNode) entry.element.parentNode.removeChild(entry.element);
      stack.splice(idx, 1);
      if (stack.length === 0) unlockBody();
      if (entry.previousFocus && entry.previousFocus.focus) {
        try { entry.previousFocus.focus(); } catch (e) { /* ignore */ }
      }
      if (typeof entry.onClose === 'function') entry.onClose();
    }, 250);
  }

  /* ========================================================================
     closeAll() — cierra todos los modales
     ======================================================================== */
  function closeAll() {
    [...stack].reverse().forEach(s => close(s.id));
  }

  /* ========================================================================
     confirm(opts) — modal de confirmación rápido (sí/no)
     ======================================================================== */
  function confirm(opts) {
    return new Promise((resolve) => {
      const { title = '¿Confirmar?', message = '', confirmText = 'Aceptar', cancelText = 'Cancelar', danger = false } = opts || {};

      const footer = document.createElement('div');
      footer.style.cssText = 'display:flex; gap:8px; width:100%; justify-content:flex-end;';

      const cancelBtn = document.createElement('button');
      cancelBtn.className = 'btn btn--ghost';
      cancelBtn.textContent = cancelText;

      const confirmBtn = document.createElement('button');
      confirmBtn.className = 'btn ' + (danger ? 'btn--danger' : 'btn--primary');
      confirmBtn.textContent = confirmText;

      footer.appendChild(cancelBtn);
      footer.appendChild(confirmBtn);

      const m = open({
        title,
        size: 'sm',
        body: '<p style="color:var(--text-2); line-height:1.5;">' + message + '</p>',
        footer
      });

      cancelBtn.addEventListener('click', () => { m.close(); resolve(false); });
      confirmBtn.addEventListener('click', () => { m.close(); resolve(true); });
    });
  }

  global.IMDIILModal = { open, close, closeAll, confirm };
})(window);
