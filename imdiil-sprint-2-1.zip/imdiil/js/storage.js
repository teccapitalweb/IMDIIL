/* ========================================================================
   IMDIIL VIP · storage.js
   API unificada de persistencia.
   HOY:    usa localStorage (guest mode).
   MAÑANA: cambia a Firestore solo aquí, sin tocar las herramientas.
   ======================================================================== */

(function (global) {
  'use strict';

  const PREFIX = 'imdiil:';
  const BACKEND_KEY = PREFIX + 'backend';

  // Backend actual ('local' o 'firestore'). Default: local.
  function getBackend() {
    return localStorage.getItem(BACKEND_KEY) || 'local';
  }

  function setBackend(backend) {
    if (backend !== 'local' && backend !== 'firestore') {
      throw new Error('Backend inválido: ' + backend);
    }
    localStorage.setItem(BACKEND_KEY, backend);
  }

  function fullKey(collection, id) {
    return PREFIX + collection + (id ? ':' + id : '');
  }

  // ---------- LOCAL BACKEND ----------
  const localBackend = {
    async save(collection, id, data) {
      const key = fullKey(collection, id);
      const payload = {
        id,
        data,
        updatedAt: new Date().toISOString(),
        createdAt: (await this.load(collection, id))?.createdAt || new Date().toISOString()
      };
      localStorage.setItem(key, JSON.stringify(payload));
      return payload;
    },

    async load(collection, id) {
      const key = fullKey(collection, id);
      const raw = localStorage.getItem(key);
      if (!raw) return null;
      try { return JSON.parse(raw); } catch (e) { return null; }
    },

    async list(collection) {
      const prefix = fullKey(collection);
      const results = [];
      for (let i = 0; i < localStorage.length; i++) {
        const key = localStorage.key(i);
        if (key && key.startsWith(prefix + ':')) {
          try {
            results.push(JSON.parse(localStorage.getItem(key)));
          } catch (e) { /* ignore */ }
        }
      }
      return results.sort((a, b) => (b.updatedAt || '').localeCompare(a.updatedAt || ''));
    },

    async remove(collection, id) {
      localStorage.removeItem(fullKey(collection, id));
      return true;
    },

    async clear(collection) {
      const prefix = fullKey(collection);
      const toRemove = [];
      for (let i = 0; i < localStorage.length; i++) {
        const key = localStorage.key(i);
        if (key && key.startsWith(prefix + ':')) toRemove.push(key);
      }
      toRemove.forEach(k => localStorage.removeItem(k));
      return toRemove.length;
    }
  };

  // ---------- FIRESTORE BACKEND (placeholder, conectar en Sprint 4) ----------
  const firestoreBackend = {
    async save(collection, id, data) {
      // TODO Sprint 4: db.collection(collection).doc(id).set(data)
      throw new Error('Firestore backend no conectado todavía. Sprint 4.');
    },
    async load(collection, id) { throw new Error('Firestore backend no conectado.'); },
    async list(collection) { throw new Error('Firestore backend no conectado.'); },
    async remove(collection, id) { throw new Error('Firestore backend no conectado.'); },
    async clear(collection) { throw new Error('Firestore backend no conectado.'); }
  };

  function getActiveBackend() {
    return getBackend() === 'firestore' ? firestoreBackend : localBackend;
  }

  /* ========================================================================
     API PÚBLICA — esto es lo que las herramientas usan
     ======================================================================== */
  const Storage = {
    /** Genera un ID único para nuevos documentos. */
    newId() {
      return 'doc_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2, 8);
    },

    /** Guarda un documento. Si id es null, genera uno nuevo. Devuelve el documento guardado. */
    async save(collection, id, data) {
      const docId = id || this.newId();
      return getActiveBackend().save(collection, docId, data);
    },

    /** Carga un documento por id. Devuelve null si no existe. */
    async load(collection, id) {
      return getActiveBackend().load(collection, id);
    },

    /** Lista todos los documentos de una colección, ordenados por updatedAt desc. */
    async list(collection) {
      return getActiveBackend().list(collection);
    },

    /** Elimina un documento. */
    async remove(collection, id) {
      return getActiveBackend().remove(collection, id);
    },

    /** Elimina TODOS los documentos de una colección. Cuidado. */
    async clear(collection) {
      return getActiveBackend().clear(collection);
    },

    /** Cambia el backend. */
    setBackend,
    getBackend,

    /** Preferencias de usuario (tema, idioma, etc.) — atajo. */
    pref: {
      get(key, defaultValue) {
        const v = localStorage.getItem(PREFIX + 'pref:' + key);
        return v === null ? defaultValue : v;
      },
      set(key, value) {
        localStorage.setItem(PREFIX + 'pref:' + key, String(value));
      }
    }
  };

  global.IMDIILStorage = Storage;
})(window);
