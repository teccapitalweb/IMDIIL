/* ========================================================================
   IMDIIL VIP · tools/logistica.js
   Indicadores Logísticos · OTIF, Fill Rate, rotación, stockout
   Placeholder estructural — implementación completa en Sprint 2.X
   ======================================================================== */

(function (global) {
  'use strict';

  const Tool = {
    name: 'Indicadores Logísticos',
    description: 'OTIF, Fill Rate, rotación, stockout',

    open() {
      IMDIILModal.open({
        id: 'logistica-tool',
        title: 'Indicadores Logísticos',
        subtitle: 'OTIF, Fill Rate, rotación, stockout',
        icon: 'i-chart-bar',
        size: 'lg',
        body:
          '<div style="text-align:center; padding:40px 20px;">' +
          '<div style="width:64px; height:64px; margin:0 auto 16px; border-radius:16px; background:var(--surface-2); display:flex; align-items:center; justify-content:center;">' +
          '<svg class="ic ic--xl" style="color:var(--primary);"><use href="#i-chart-bar"/></svg>' +
          '</div>' +
          '<h3 style="font-size:18px; font-weight:600; margin-bottom:8px;">Indicadores Logísticos · próximamente</h3>' +
          '<p style="color:var(--text-2); max-width:480px; margin:0 auto; line-height:1.6;">' +
          '4 calculadoras integradas con benchmarks por sector, dashboard visual y reporte mensual PDF.' +
          '</p>' +
          '</div>',
        footer:
          '<button class="btn btn--ghost" onclick="IMDIILModal.close(\'logistica-tool\')">Cerrar</button>'
      });
    }
  };

  global.IMDIILTools = global.IMDIILTools || {};
  global.IMDIILTools.logistica = Tool;
})(window);
