/* ========================================================================
   IMDIIL VIP · tools/oee.js
   Calculadora OEE · Overall Equipment Effectiveness
   Placeholder estructural — implementación completa en Sprint 2.X
   ======================================================================== */

(function (global) {
  'use strict';

  const Tool = {
    name: 'Calculadora OEE',
    description: 'Overall Equipment Effectiveness',

    open() {
      IMDIILModal.open({
        id: 'oee-tool',
        title: 'Calculadora OEE',
        subtitle: 'Overall Equipment Effectiveness',
        icon: 'i-gauge',
        size: 'lg',
        body:
          '<div style="text-align:center; padding:40px 20px;">' +
          '<div style="width:64px; height:64px; margin:0 auto 16px; border-radius:16px; background:var(--surface-2); display:flex; align-items:center; justify-content:center;">' +
          '<svg class="ic ic--xl" style="color:var(--primary);"><use href="#i-gauge"/></svg>' +
          '</div>' +
          '<h3 style="font-size:18px; font-weight:600; margin-bottom:8px;">Calculadora OEE · próximamente</h3>' +
          '<p style="color:var(--text-2); max-width:480px; margin:0 auto; line-height:1.6;">' +
          'Disponibilidad × Rendimiento × Calidad, con gauges visuales animados, clasificación World-class y reporte PDF.' +
          '</p>' +
          '</div>',
        footer:
          '<button class="btn btn--ghost" onclick="IMDIILModal.close(\'oee-tool\')">Cerrar</button>'
      });
    }
  };

  global.IMDIILTools = global.IMDIILTools || {};
  global.IMDIILTools.oee = Tool;
})(window);
