/* ========================================================================
   IMDIIL VIP · pdf-engine.js
   Motor de PDFs con identidad oficial IMDIIL.
   Usa jsPDF + jspdf-autotable (cargados desde CDN en vip-panel.html).

   API:
     const pdf = IMDIILPDF.create({ title, subtitle, folio });
     pdf.h1('Título de sección');
     pdf.text('Párrafo...');
     pdf.kv([['Clave', 'Valor'], ...]);
     pdf.table({ head: [...], body: [[...], ...] });
     pdf.spacer(10);
     pdf.signatures(['Trabajador', 'Supervisor', 'Jefe SSO']);
     pdf.save('matriz-iper-XXX.pdf');
   ======================================================================== */

(function (global) {
  'use strict';

  // ---------- Paleta institucional IMDIIL ----------
  const COLORS = {
    primary: [255, 122, 45],     // #FF7A2D naranja casco
    primaryDeep: [232, 90, 20],   // #E85A14
    text: [26, 20, 16],           // #1A1410 warm black
    textSoft: [90, 80, 68],       // #5A5044
    textMuted: [138, 127, 112],   // #8A7F70
    border: [220, 210, 195],
    surface: [250, 246, 235],
    white: [255, 255, 255]
  };

  function generateFolio() {
    const y = new Date().getFullYear();
    const r = Math.floor(Math.random() * 90000) + 10000;
    return 'IMDIIL-' + y + '-' + r;
  }

  function formatDate(d = new Date()) {
    const months = ['enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio',
      'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre'];
    return d.getDate() + ' de ' + months[d.getMonth()] + ' de ' + d.getFullYear();
  }

  /* ========================================================================
     PDFBuilder — instancia individual de un documento
     ======================================================================== */
  class PDFBuilder {
    constructor(config) {
      if (!global.jspdf) {
        throw new Error('jsPDF no está cargado. Verifica el <script> de jsPDF en el HTML.');
      }
      const { jsPDF } = global.jspdf;
      this.doc = new jsPDF({ unit: 'mm', format: 'a4', orientation: 'portrait' });
      this.pageWidth = 210;
      this.pageHeight = 297;
      this.margin = 18;
      this.contentWidth = this.pageWidth - (this.margin * 2);

      this.title = config.title || 'Documento IMDIIL';
      this.subtitle = config.subtitle || '';
      this.folio = config.folio || generateFolio();
      this.date = config.date || new Date();

      this.cursorY = 0;
      this.drawHeader();
      this.cursorY = 56;
    }

    /* ---------- HEADER (membrete institucional) ---------- */
    drawHeader() {
      const d = this.doc;

      // Banda superior naranja
      d.setFillColor(...COLORS.primary);
      d.rect(0, 0, this.pageWidth, 4, 'F');

      // Logo (simplificado en SVG-paths-to-pdf via texto + ícono mínimo)
      d.setFillColor(...COLORS.text);
      // "Edificio" representado por 3 barras verticales
      d.rect(this.margin, 14, 2.5, 18, 'F');
      d.rect(this.margin + 4, 18, 2.5, 14, 'F');
      d.rect(this.margin + 8, 12, 2.5, 20, 'F');
      // Casco (semicírculo)
      d.setFillColor(...COLORS.primary);
      d.ellipse(this.margin + 6, 34, 6, 3, 'F');
      d.rect(this.margin, 33.5, 12, 2, 'F');

      // Nombre marca
      d.setFont('helvetica', 'bold');
      d.setFontSize(16);
      d.setTextColor(...COLORS.text);
      d.text('IMDIIL', this.margin + 16, 22);

      d.setFont('helvetica', 'normal');
      d.setFontSize(8);
      d.setTextColor(...COLORS.textSoft);
      d.text('Instituto Mexicano de Ingeniería Industrial y Logística', this.margin + 16, 27);
      d.text('www.imdiil.com   ·   IMDIIL Panel VIP', this.margin + 16, 31);

      // Folio + fecha en la esquina derecha
      d.setFont('helvetica', 'bold');
      d.setFontSize(8);
      d.setTextColor(...COLORS.textMuted);
      d.text('FOLIO', this.pageWidth - this.margin, 16, { align: 'right' });
      d.setFont('helvetica', 'bold');
      d.setFontSize(10);
      d.setTextColor(...COLORS.text);
      d.text(this.folio, this.pageWidth - this.margin, 21, { align: 'right' });

      d.setFont('helvetica', 'normal');
      d.setFontSize(8);
      d.setTextColor(...COLORS.textMuted);
      d.text('EMITIDO', this.pageWidth - this.margin, 27, { align: 'right' });
      d.setFontSize(9);
      d.setTextColor(...COLORS.textSoft);
      d.text(formatDate(this.date), this.pageWidth - this.margin, 31, { align: 'right' });

      // Línea separadora
      d.setDrawColor(...COLORS.border);
      d.setLineWidth(0.3);
      d.line(this.margin, 38, this.pageWidth - this.margin, 38);

      // Título del documento
      d.setFont('helvetica', 'bold');
      d.setFontSize(16);
      d.setTextColor(...COLORS.text);
      d.text(this.title, this.margin, 47);

      if (this.subtitle) {
        d.setFont('helvetica', 'normal');
        d.setFontSize(9.5);
        d.setTextColor(...COLORS.textSoft);
        d.text(this.subtitle, this.margin, 52);
      }
    }

    /* ---------- FOOTER ---------- */
    drawFooter(pageNum, totalPages) {
      const d = this.doc;
      const y = this.pageHeight - 12;

      d.setDrawColor(...COLORS.border);
      d.setLineWidth(0.3);
      d.line(this.margin, y - 4, this.pageWidth - this.margin, y - 4);

      d.setFont('helvetica', 'normal');
      d.setFontSize(7.5);
      d.setTextColor(...COLORS.textMuted);
      d.text('Documento generado por IMDIIL · www.imdiil.com · Folio ' + this.folio, this.margin, y);

      d.text('Página ' + pageNum + ' de ' + totalPages, this.pageWidth - this.margin, y, { align: 'right' });
    }

    /* ---------- Asegurar espacio en la página ---------- */
    ensureSpace(needed) {
      if (this.cursorY + needed > this.pageHeight - 22) {
        this.doc.addPage();
        this.drawHeader();
        this.cursorY = 56;
      }
    }

    /* ---------- HEADINGS ---------- */
    h1(text) {
      this.ensureSpace(14);
      const d = this.doc;
      d.setFont('helvetica', 'bold');
      d.setFontSize(13);
      d.setTextColor(...COLORS.text);
      d.text(text, this.margin, this.cursorY);
      // Subrayado naranja
      d.setDrawColor(...COLORS.primary);
      d.setLineWidth(0.8);
      d.line(this.margin, this.cursorY + 1.5, this.margin + 8, this.cursorY + 1.5);
      this.cursorY += 8;
      return this;
    }

    h2(text) {
      this.ensureSpace(10);
      const d = this.doc;
      d.setFont('helvetica', 'bold');
      d.setFontSize(10.5);
      d.setTextColor(...COLORS.textSoft);
      d.text(text.toUpperCase(), this.margin, this.cursorY);
      this.cursorY += 6;
      return this;
    }

    /* ---------- TEXT ---------- */
    text(content, opts = {}) {
      const d = this.doc;
      d.setFont('helvetica', opts.bold ? 'bold' : 'normal');
      d.setFontSize(opts.size || 9.5);
      d.setTextColor(...(opts.color || COLORS.text));
      const lines = d.splitTextToSize(content, this.contentWidth);
      this.ensureSpace(lines.length * 4.5 + 2);
      d.text(lines, this.margin, this.cursorY);
      this.cursorY += lines.length * 4.5 + 2;
      return this;
    }

    /* ---------- KEY-VALUE (lista de campos) ---------- */
    kv(rows, opts = {}) {
      const d = this.doc;
      const cols = opts.cols || 2;
      const colW = this.contentWidth / cols;
      const rowH = 11;

      rows.forEach((row, i) => {
        const col = i % cols;
        if (col === 0 && i > 0) this.cursorY += rowH;
        this.ensureSpace(rowH);
        const x = this.margin + (col * colW);

        d.setFont('helvetica', 'bold');
        d.setFontSize(7.5);
        d.setTextColor(...COLORS.textMuted);
        d.text(String(row[0]).toUpperCase(), x, this.cursorY);

        d.setFont('helvetica', 'normal');
        d.setFontSize(10);
        d.setTextColor(...COLORS.text);
        const valLines = d.splitTextToSize(String(row[1] || '—'), colW - 4);
        d.text(valLines, x, this.cursorY + 5);
      });
      this.cursorY += rowH + 2;
      return this;
    }

    /* ---------- TABLE (usa autoTable) ---------- */
    table(opts) {
      this.ensureSpace(20);
      this.doc.autoTable({
        head: opts.head,
        body: opts.body,
        startY: this.cursorY,
        margin: { left: this.margin, right: this.margin },
        styles: {
          font: 'helvetica',
          fontSize: 9,
          cellPadding: 3.5,
          textColor: COLORS.text,
          lineColor: COLORS.border,
          lineWidth: 0.2
        },
        headStyles: {
          fillColor: COLORS.text,
          textColor: COLORS.white,
          fontStyle: 'bold',
          fontSize: 8.5,
          halign: 'left'
        },
        alternateRowStyles: {
          fillColor: COLORS.surface
        },
        columnStyles: opts.columnStyles || {},
        didDrawCell: opts.didDrawCell,
        didParseCell: opts.didParseCell
      });
      this.cursorY = this.doc.lastAutoTable.finalY + 6;
      return this;
    }

    /* ---------- SPACER ---------- */
    spacer(h = 5) {
      this.cursorY += h;
      return this;
    }

    /* ---------- BANNER de resultado (recuadro con texto destacado) ---------- */
    banner(text, color = 'primary') {
      this.ensureSpace(14);
      const d = this.doc;
      const colorRGB = color === 'success' ? [15, 157, 88]
                    : color === 'warn' ? [232, 155, 31]
                    : color === 'danger' ? [220, 45, 63]
                    : COLORS.primary;
      d.setFillColor(...colorRGB);
      d.roundedRect(this.margin, this.cursorY, this.contentWidth, 12, 2, 2, 'F');
      d.setFont('helvetica', 'bold');
      d.setFontSize(11);
      d.setTextColor(255, 255, 255);
      d.text(text, this.margin + 5, this.cursorY + 7.5);
      this.cursorY += 16;
      return this;
    }

    /* ---------- SIGNATURES (líneas para firmar) ---------- */
    signatures(roles) {
      this.ensureSpace(28);
      const d = this.doc;
      const colW = this.contentWidth / roles.length;
      const lineY = this.cursorY + 14;

      roles.forEach((role, i) => {
        const cx = this.margin + (colW * i) + (colW / 2);
        d.setDrawColor(...COLORS.text);
        d.setLineWidth(0.3);
        d.line(cx - colW * 0.35, lineY, cx + colW * 0.35, lineY);
        d.setFont('helvetica', 'bold');
        d.setFontSize(8);
        d.setTextColor(...COLORS.textSoft);
        d.text(role.toUpperCase(), cx, lineY + 4, { align: 'center' });
        d.setFont('helvetica', 'normal');
        d.setFontSize(7);
        d.setTextColor(...COLORS.textMuted);
        d.text('Nombre y firma', cx, lineY + 8, { align: 'center' });
      });
      this.cursorY += 26;
      return this;
    }

    /* ---------- SAVE ---------- */
    save(filename) {
      const total = this.doc.internal.getNumberOfPages();
      for (let i = 1; i <= total; i++) {
        this.doc.setPage(i);
        this.drawFooter(i, total);
      }
      this.doc.save(filename || ('IMDIIL-' + this.folio + '.pdf'));
      return this;
    }

    /** Devuelve el PDF como Blob (para abrir en nueva pestaña, etc). */
    blob() {
      const total = this.doc.internal.getNumberOfPages();
      for (let i = 1; i <= total; i++) {
        this.doc.setPage(i);
        this.drawFooter(i, total);
      }
      return this.doc.output('blob');
    }
  }

  /* ========================================================================
     API pública
     ======================================================================== */
  global.IMDIILPDF = {
    create(config) {
      return new PDFBuilder(config || {});
    },
    generateFolio,
    formatDate
  };
})(window);
