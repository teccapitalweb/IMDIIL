# IMDIIL VIP · Panel modular

Panel VIP de IMDIIL con arquitectura modular pensada para escalar sin refactors. Se sirve desde GitHub Pages en `https://www.imdiil.com/`.

## 📁 Estructura

```
IMDIIL/
├── index.html                  ← landing público (ya existía)
├── vip-panel.html              ← entrada al panel (esqueleto + sprite SVG)
├── manifest.json               ← PWA manifest
├── service-worker.js           ← offline support
│
├── /css/
│   ├── core.css                ← variables, paleta, reset, layout
│   ├── components.css          ← botones, cards, modales, formularios
│   ├── tools.css               ← estilos de las 5 herramientas pro
│   └── responsive.css          ← media queries
│
├── /js/
│   ├── app.js                  ← init, theme, KPIs, countdown, navigation, toasts
│   ├── modal.js                ← sistema accesible de modales (focus trap, ESC, etc.)
│   ├── storage.js              ← API unificada (hoy localStorage, mañana Firestore)
│   ├── pdf-engine.js           ← jsPDF wrapper con membrete oficial IMDIIL
│   └── /tools/
│       ├── iper.js             ← Matriz IPER
│       ├── oee.js              ← Calculadora OEE
│       ├── ats.js              ← Generador ATS
│       ├── noms.js             ← Tabla NOM-STPS
│       └── logistica.js        ← Indicadores logísticos
│
├── /data/
│   └── noms.json               ← base de datos de NOMs (Sprint 2.5)
│
└── /assets/
    ├── /img/                   ← logos, banners (ya existía)
    └── /icons/                 ← PWA icons 192/512 maskable
```

## 🚀 Deploy

1. Sube la carpeta `IMDIIL/` completa al root del repo `teccapitalweb/IMDIIL` rama `main`.
2. GitHub Pages sirve desde `/` (ya configurado).
3. URL final: `https://www.imdiil.com/vip-panel.html`.

## 🧱 Cómo agregar una herramienta nueva

1. Crear `js/tools/mi-herramienta.js` siguiendo el patrón:

```js
(function (global) {
  'use strict';
  const Tool = {
    name: 'Mi Herramienta',
    open() {
      IMDIILModal.open({
        id: 'mi-herramienta',
        title: 'Mi Herramienta',
        icon: 'i-shield-check',
        body: '<form>...</form>',
        footer: '<button class="btn btn--primary" id="my-btn">Generar PDF</button>'
      });
      document.getElementById('my-btn').addEventListener('click', generar);
    }
  };
  global.IMDIILTools = global.IMDIILTools || {};
  global.IMDIILTools.miHerramienta = Tool;
})(window);
```

2. Importarla en `vip-panel.html` antes de `app.js`:
```html
<script src="/js/tools/mi-herramienta.js"></script>
```

3. Agregar el botón en sidebar/tools-grid con `data-section="miHerramienta"` o `data-tool="miHerramienta"`.

## 💾 Storage API

Todas las herramientas usan la misma API. Hoy guarda en `localStorage`, mañana cambia a Firestore sin tocar las herramientas.

```js
// Guardar
const doc = await IMDIILStorage.save('iper', null, { actividad: 'Soldadura', riesgo: 16 });
// doc.id  doc.data  doc.createdAt  doc.updatedAt

// Cargar
const doc = await IMDIILStorage.load('iper', 'doc_abc123');

// Listar
const all = await IMDIILStorage.list('iper');

// Eliminar
await IMDIILStorage.remove('iper', 'doc_abc123');

// Preferencias rápidas (tema, idioma)
IMDIILStorage.pref.set('theme', 'day');
const t = IMDIILStorage.pref.get('theme', 'night');
```

## 📄 Generar PDFs con membrete IMDIIL

```js
const pdf = IMDIILPDF.create({
  title: 'Matriz IPER',
  subtitle: 'Identificación de peligros y evaluación de riesgos'
});

pdf.h1('Datos generales')
   .kv([['Empresa', 'Marval'], ['Área', 'Soldadura'], ['Fecha', '2026-05-25']])
   .h1('Peligros identificados')
   .table({
     head: [['Peligro', 'P', 'S', 'Magnitud', 'Nivel']],
     body: [['Caída', 3, 4, 12, 'Importante']]
   })
   .banner('Magnitud máxima: 16 — Intolerable', 'danger')
   .signatures(['Trabajador', 'Supervisor', 'Jefe SSO'])
   .save('matriz-iper-001.pdf');
```

El PDF sale con:
- Banda naranja superior + logo IMDIIL
- Folio automático `IMDIIL-2026-XXXXX`
- Fecha de emisión
- Footer con paginación

## 🪟 Modales

```js
const modal = IMDIILModal.open({
  id: 'mi-modal',
  title: 'Título',
  subtitle: 'Subtítulo opcional',
  icon: 'i-shield-check',
  size: 'lg',  // 'sm' | 'md' (default) | 'lg'
  body: '<form>...</form>',  // string HTML o Node
  footer: footerNode
});

// Confirmación rápida (sí/no)
const ok = await IMDIILModal.confirm({
  title: '¿Eliminar matriz?',
  message: 'Esta acción no se puede deshacer.',
  confirmText: 'Eliminar',
  danger: true
});
```

## 🌗 Tema día/noche

- `IMDIILApp.theme.apply('day')` o `'night'`
- `IMDIILApp.theme.toggle()`
- Se guarda en `IMDIILStorage.pref` automáticamente

## 🔔 Toasts

```js
IMDIILApp.toast.success('Guardado', 'Tu matriz IPER se guardó correctamente');
IMDIILApp.toast.error('Error', 'No se pudo guardar');
IMDIILApp.toast.info('Aviso', 'Próxima clase en vivo el jueves');
```

## 📱 PWA

Manifest + Service Worker registrados. La PWA es instalable desde Chrome/Safari móvil:
- En Android: menú → "Instalar app"
- En iOS: compartir → "Añadir a pantalla de inicio"

Las herramientas pro funcionan **offline** después de la primera visita (Service Worker cachea todos los assets estáticos).

⚠️ Falta generar los íconos PWA `assets/icons/icon-192.png`, `icon-512.png`, y variantes maskable. Sin ellos, el `manifest.json` da warning pero el panel funciona.

## 🛣️ Roadmap

- ✅ Sprint 2.1 · Infraestructura modular (este sprint)
- ⏳ Sprint 2.2 · Matriz IPER funcional
- ⏳ Sprint 2.3 · Calculadora OEE con gauges SVG
- ⏳ Sprint 2.4 · Generador ATS multi-paso
- ⏳ Sprint 2.5 · Tabla NOM-STPS con base de datos real
- ⏳ Sprint 2.6 · Indicadores logísticos
- ⏳ Sprint 3 · Mis cursos · Foro · Logros · Certificados
- ⏳ Sprint 4 · Firebase Auth + Stripe + paywall guest/VIP
